import React from 'react'
import './Games.css'

export default function Games({ data}) {
  console.log(data)
  return (
    <div className='Games'>
      {/* dau ch?m h?i khi m? g?i api l?n ??u ti?n s? kh?ng c? d? li?u d?u ch?m h?i ?? ng?n ch?n l?i ki?m tra kh?ng c? d? li?u
        m?y c?i tham s? d??i a truy?n v?o nh?
      */}
      <h3>{`${data?.home_team?.full_name} [${data?.home_team?.abbreviation}]`}</h3>
      <h5>tile old</h5>
      <hr/>
      <div className='ResultGames'>
        <p>Results of part 12 days</p>
        <label>W L W W</label>
        <p>Avg pts scored:109</p>
        <p>Avg pts conceded:113</p>
        <img src='/' alt='ImageLogo'></img>
        <br/>
        <button>See game results..</button>
      </div>
    </div>
  )
}
