import React from 'react'
import HomeScoreTracking from './Components/HomeScoreTracking/HomeScoreTracking'

export default function App() {


  return (
      <HomeScoreTracking />
    
  
  )
}

