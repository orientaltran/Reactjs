import React, { Component } from 'react'

export default class Product extends Component {
  render() {
    return (
      <div>Product</div>
    )
  }
}
