import React, { Component } from 'react'

export default class Stopwatch extends Component {
  render() {
    return (
      <div>Stopwatch</div>
    )
  }
}
